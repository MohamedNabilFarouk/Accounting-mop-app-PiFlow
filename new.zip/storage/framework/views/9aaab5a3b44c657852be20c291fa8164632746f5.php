


<?php $__env->startSection('toolbar'); ?>
    <div class="toolbar" id="kt_toolbar">
        <!--begin::Container-->
        <div id="kt_toolbar_container" class="container-fluid d-flex flex-stack">
            <!--begin::Page title-->
            <div class="d-flex align-items-center me-3">
                <!--begin::Title-->
                <h1 class="d-flex align-items-center text-dark fw-bolder my-1 fs-3"><?php echo app('translator')->get('Justification'); ?>
                    <!--begin::Separator-->
                    <span class="h-20px border-gray-200 border-start ms-3 mx-2"></span>
                    <!--end::Separator-->
                    <!--begin::Description-->
                    <small class="text-muted fs-7 fw-bold my-1 ms-1"></small>
                    <!--end::Description-->
                </h1>
                <!--end::Title-->
            </div>
            <!--end::Page title-->

        </div>
        <!--end::Container-->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid page__container p-2">

        <div class="card rounded card-form__body card-body shadow-lg">
            <form method="POST" action="<?php echo e(route('justification.update',$row->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
                <div class="form-group mb-10">
                    <label for="exampleFormControlInput1" class="required form-label"><?php echo app('translator')->get('bank name'); ?></label>
                    <input type='text' name="bank_name" class="form-control" value="<?php echo e($row->bank_name); ?>" required  />
                </div>
                <div class="form-group mb-10">
                    <label for="exampleFormControlInput1" class="required form-label"><?php echo app('translator')->get('bank number '); ?></label>
                    <input type='text' name="bank_number" class="form-control" value="<?php echo e($row->bank_number); ?>" required/>
                </div>

                <div class="form-group mb-10">
                    <label for="exampleFormControlInput1" class="required form-label"><?php echo app('translator')->get('piflow comment'); ?></label>
                    <textarea  class="form-control" name="piflow_comment"><?php echo e($row->piflow_comment); ?></textarea>
                </div>
                <div class="form-group mb-10">
                    <label for="exampleFormControlInput1" class="required form-label"><?php echo app('translator')->get('Client comment'); ?></label>
                    <textarea  class="form-control" name="client_comment" readonly><?php echo e($row->client_comment); ?></textarea>
                </div>
                <div class="form-group mb-10">
                    <label class="required form-label"><?php echo app('translator')->get('Description'); ?></label>
                        <textarea  class="form-control" name="des"><?php echo e($row->des); ?></textarea>
                </div>
                <div class="form-group mb-10">
                    <label class="required form-label"><?php echo app('translator')->get('transaction date'); ?></label>
                    <input type="date" class="form-control" name="trans_date" value="<?php echo e($row->trans_date); ?>" required >

                </div>

               
                <input type="hidden" class="form-control" value='<?php echo e($row->date); ?>' name="date"  >
                <input type="hidden" class="form-control" value='<?php echo e($row->company_id); ?>' name="company_id" >
              </div> 

                
             
                <div class="text-right mb-5">
                    <input type="submit" class="btn btn-success" value="<?php echo app('translator')->get('Add'); ?>">
                </div>
            </form>
        </div>
    </div>
    <!-- // END drawer-layout__content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Billy\new app\new\resources\views/admin/justification/edit.blade.php ENDPATH**/ ?>