<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php if(Session::has('success')): ?>

    <div class="alert alert-success">
        <ul>
            <li><?php echo e(Session::get('success')); ?></li>
        </ul>
    </div>

<?php endif; ?>

<?php if(Session::has('Error')): ?>

    <div class="alert alert-danger">
        <ul>
            <li><?php echo e(Session::get('Error')); ?></li>
        </ul>
    </div>

<?php endif; ?>
<?php /**PATH D:\Billy\new app\new\resources\views/admin/includes/messages.blade.php ENDPATH**/ ?>