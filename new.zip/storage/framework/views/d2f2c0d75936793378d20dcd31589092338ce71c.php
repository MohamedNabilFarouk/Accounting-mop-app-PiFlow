[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH D:\Billy\new app\mobapp\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>