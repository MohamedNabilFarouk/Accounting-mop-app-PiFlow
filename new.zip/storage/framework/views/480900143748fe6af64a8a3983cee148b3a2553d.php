


<?php $__env->startSection('toolbar'); ?>
    <div class="toolbar" id="kt_toolbar">
        <!--begin::Container-->
        <div id="kt_toolbar_container" class="container-fluid d-flex flex-stack">
            <!--begin::Page title-->
            <div class="d-flex align-items-center me-3">
                <!--begin::Title-->
                <h1 class="d-flex align-items-center text-dark fw-bolder my-1 fs-3"><?php echo app('translator')->get('Metrics'); ?>
                    <!--begin::Separator-->
                    <span class="h-20px border-gray-200 border-start ms-3 mx-2"></span>
                    <!--end::Separator-->
                    <!--begin::Description-->
                    <small class="text-muted fs-7 fw-bold my-1 ms-1"></small>
                    <!--end::Description-->
                </h1>
                <!--end::Title-->
            </div>
            <!--end::Page title-->

        </div>
        <!--end::Container-->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-fluid page__container p-2">

        <div class="card rounded card-form__body card-body shadow-lg">
            <form method="POST" action="<?php echo e(route('metrics.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

<?php if($row == '[]' || $row == null): ?>
                <div class="form-group mb-10">
                    <label for="exampleFormControlInput1" class="required form-label"><?php echo app('translator')->get('total sales'); ?></label>
                    <input type='text' name="total_sales" class="form-control" value="<?php echo e(old('total_sales')); ?>" required />
                </div>
                <div class="form-group mb-10">
                    <label for="exampleFormControlInput1" class="required form-label"><?php echo app('translator')->get('total purchases '); ?></label>
                    <input type='text' name="total_purchases" class="form-control" value="<?php echo e(old('total_purchases')); ?>" />
                </div>


                <div class="form-group mb-10">
                    <label for="exampleFormControlInput1" class="required form-label"><?php echo app('translator')->get('gross margin'); ?></label>
                    <input type="text" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="gross_margin" value="<?php echo e(old('gross_margin')); ?>"  required>

                </div>
                <div class="form-group mb-10">
                    <label class="required form-label"><?php echo app('translator')->get('net profit'); ?></label>
                    <input type="text" class="form-control" name="net_profit" value="<?php echo e(old('net_profit')); ?>" required>

                </div>

                <div class="form-group mb-10">
                    <label for="exampleFormControlInput1" class="required form-label"><?php echo app('translator')->get('Files'); ?></label>
                    <input type='file' name="file[]" class="form-control" value="<?php echo e(old('file')); ?>" multiple />
                </div>

                <?php else: ?>

                <div class="form-group mb-10">
                    <label for="exampleFormControlInput1" class="required form-label"><?php echo app('translator')->get('total sales'); ?></label>
                    <input type='text' name="total_sales" class="form-control" value="<?php echo e($row->total_sales); ?>" required />
                </div>
                <div class="form-group mb-10">
                    <label for="exampleFormControlInput1" class="required form-label"><?php echo app('translator')->get('total purchases '); ?></label>
                    <input type='text' name="total_purchases" class="form-control" value="<?php echo e($row->total_purchases); ?>" />
                </div>


                <div class="form-group mb-10">
                    <label for="exampleFormControlInput1" class="required form-label"><?php echo app('translator')->get('gross margin'); ?></label>
                    <input type="text" class="form-control" name="gross_margin" value="<?php echo e($row->gross_margin); ?>"  required>

                </div>
                <div class="form-group mb-10">
                    <label class="required form-label"><?php echo app('translator')->get('net profit'); ?></label>
                    <input type="text" class="form-control" name="net_profit" value="<?php echo e($row->net_profit); ?>" required>

                </div>
<div class="row">
                <div class="form-group mb-10 col-md-3">
                <div class="form-group mb-10">
                    <label for="exampleFormControlInput1" class="required form-label"><?php echo app('translator')->get('Files'); ?></label>
                    <input type='file' name="file[]" class="form-control" value="<?php echo e($row->file); ?>" multiple />
                </div>
                </div>
                <?php if($row->files != []): ?>
                
                <?php $__currentLoopData = $row->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 mt-5">  
                   
                        <div class="alert <?php if($key%2 == 0): ?> alert-warning <?php else: ?>  alert-primary   <?php endif; ?>   " >
                               <?php echo e($r['file_name']); ?> 
                               <a download="<?php echo e($r['file_name']); ?>" href="<?php echo e(asset($r['file_path'])); ?>" >
                                <i class="fa fa-lg fa-download" style='float:right'></i>
                               </a>
                    
                                <a  class="btn btn-xs" href="<?php echo e(route('metrics.delete.file',[$row->id,$key])); ?>" style='margin:-15px 0px 0 0; float:right'><i
                                    class="fa fa-trash"></i> 
                                </a>
                               
                               
                               
                            </div>
                  
                </div>   
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
</div> 

                <?php endif; ?>
                <input type="hidden" class="form-control" value='<?php echo e($date); ?>' name="date"  required>
                <input type="hidden" class="form-control" value='<?php echo e($company_id); ?>' name="company_id"  required>
             



              



                <div class="text-right mb-5">
                    <input type="submit" class="btn btn-success" value="<?php echo app('translator')->get('Add'); ?>">
                </div>
            </form>
        </div>
    </div>
    <!-- // END drawer-layout__content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Billy\new app\new\resources\views/admin/metrics/create.blade.php ENDPATH**/ ?>