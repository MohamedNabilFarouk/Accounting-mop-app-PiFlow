<?php $__env->startSection('toolbar'); ?>
    <div class="toolbar" id="kt_toolbar">
        <!--begin::Container-->
        <div id="kt_toolbar_container" class="container-fluid d-flex flex-stack">
            <!--begin::Page title-->
            <div class="d-flex align-items-center me-3">
                <!--begin::Title-->
                <h1 class="d-flex align-items-center text-dark fw-bolder my-1 fs-3"><?php echo app('translator')->get('User'); ?>
                    <!--begin::Separator-->
                    <span class="h-20px border-gray-200 border-start ms-3 mx-2"></span>
                    <!--end::Separator-->
                    <!--begin::Description-->
                    <small class="text-muted fs-7 fw-bold my-1 ms-1"><?php echo app('translator')->get('Edit'); ?></small>
                    <!--end::Description-->
                </h1>
                <!--end::Title-->
            </div>
            <!--end::Page title-->

        </div>
        <!--end::Container-->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-fluid page__container p-2">

        <div class="card rounded card-form__body card-body shadow-lg">
            <form method="post" action="<?php echo e(route('user.update', $user->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <input type="hidden" value="<?php echo e(url()->previous()); ?>" name="urlPage" />
                <div class="form-group mb-10">
                    <label for="exampleFormControlInput1" class="required form-label"><?php echo app('translator')->get('name'); ?></label>
                    <input type='text' name="name" class="form-control" value="<?php echo e($user->name); ?>" />
                </div>
                <div class="form-group mb-10">
                    <label for="exampleFormControlInput1" class="required form-label"><?php echo app('translator')->get('Email'); ?></label>
                    <input type='text' name="email" class="form-control" value="<?php echo e($user->email); ?>" />
                </div>

                


                <div class="form-group mb-10">
                    <label for="exampleFormControlInput1" class="required form-label"><?php echo app('translator')->get('password'); ?></label>
                    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="password"  autocomplete="new-password">

                </div>
                <div class="form-group mb-10">
                    <label for="exampleFormControlInput1" class="required form-label"><?php echo app('translator')->get('confirm'); ?>
                        <?php echo app('translator')->get('password'); ?></label>
                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation"
                        autocomplete="new-password">

                </div>

                

           



                




                <div class="text-right mb-5">
                    <input type="submit" class="btn btn-success" value="<?php echo app('translator')->get('Edit'); ?>">
                </div>
            </form>
        </div>
    </div>
    <!-- // END drawer-layout__content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Billy\new app\new\resources\views/admin/user/edit.blade.php ENDPATH**/ ?>