




<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="card rounded mb-5 mb-xl-8 shadow-lg">
     <!--begin::Header-->
     <div class="card-header rounded border-0 pt-5">
        <h3 class="card-title align-items-start flex-column">
            <span class="card-label fw-bolder fs-3 mb-1"><?php echo app('translator')->get('Files'); ?></span>
        </h3>
    
    </div>
    <!--end::Header--
    <!--begin::Body-->
    <div class="card-body py-3">

<?php if(isset($employee_info)): ?>


 <!--begin::Table container-->
 <div class="table-responsive rounded">
    <!--begin::Table-->
    <table class="table table-hover align-middle gs-0 gy-4">
        <!--begin::Table head-->
        <thead>
            <tr class="text-center border-3 fw-bolder text-muted bg-light">
                <th class="min-w-125px"><?php echo app('translator')->get('Description'); ?></th>
                <th class="min-w-125px"><?php echo app('translator')->get('Amount'); ?></th>
            </tr>
        </thead>
        <!--end::Table head-->
        <!--begin::Table body-->
        <tbody>
            <tr class="text-center border-3 m-auto">
                <td class="px-3"><?php echo e($employee_info->des); ?></td>
                <td class="px-3"><?php echo e($employee_info->amount); ?></td>
        </tbody>
    </table>
</div> 

<hr>

<?php endif; ?>

        <!--begin::Table container-->
        <div class="table-responsive rounded">
            <div class="row g-5 g-xl-8">
                
                <?php $__currentLoopData = $fileData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-12">
                    <!--begin::Statistics Widget 5-->
                    
                    <a download="<?php echo e($r['file_name']); ?>" href="<?php echo e(asset($r['file_path'])); ?>" >
                        <div class="alert <?php if($key%2 == 0): ?> alert-warning <?php else: ?>  alert-primary   <?php endif; ?>   " >
                            
                               <?php echo e($r['file_name']); ?>

                            
                            <i class="fa fa-lg fa-download" style='float:right'></i>
                        </div>
                        
                        <!--begin::Body-->
                     
                        <!--end::Body-->
                    </a>
                    <!--end::Statistics Widget 5-->
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <!--end::Table container-->
    </div>
    <!--begin::Body-->
</div>
<!--end::Tables Widget 11-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Billy\new app\mobapp\resources\views/admin/user/files.blade.php ENDPATH**/ ?>