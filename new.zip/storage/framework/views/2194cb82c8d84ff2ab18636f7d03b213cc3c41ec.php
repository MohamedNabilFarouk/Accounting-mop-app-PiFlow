


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


<?php $__env->startSection('toolbar'); ?>
    <div class="toolbar" id="kt_toolbar">
        <!--begin::Container-->
        <div id="kt_toolbar_container" class="container-fluid d-flex flex-stack">
            <!--begin::Page title-->
            <div class="d-flex align-items-center me-3">
                <!--begin::Title-->
                <h1 class="d-flex align-items-center text-dark fw-bolder my-1 fs-3"><?php echo app('translator')->get('notifications'); ?>
                <!--begin::Separator-->
                    <!--end::Separator-->
                    <!--begin::Description-->
                    <!--end::Description--></h1>
                <!--end::Title-->
            </div>
            <!--end::Page title-->

        </div>
        <!--end::Container-->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card rounded mb-5 mb-xl-8 shadow-lg">
    <!--begin::Header-->
    <div class="card-header rounded border-0 pt-5">
        <h3 class="card-title align-items-start flex-column">
            <span class="card-label fw-bolder fs-3 mb-1"><?php echo app('translator')->get('All'); ?> <?php echo app('translator')->get('notifications'); ?></span>
        </h3>

    </div>
    <!--end::Header-->
    <!--begin::Body-->
    <div class="card-body py-3">

        <?php echo $__env->make('admin.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <!--begin::Table-->
 <table class="table table-hover align-middle gs-0 gy-4">
    <!--begin::Table head-->
    <thead>
        <tr class="text-center border-3 fw-bolder text-muted bg-light">
            <th class="min-w-125px"><?php echo app('translator')->get('User'); ?></th>
            <th class="min-w-125px"><?php echo app('translator')->get('Title'); ?></th>
            <th class="min-w-125px"><?php echo app('translator')->get('Body'); ?></th>
            <th class="min-w-125px"><?php echo app('translator')->get('Type'); ?></th>
            <th class="min-w-125px"><?php echo app('translator')->get('At'); ?></th>
        </tr>
    </thead>
    <tbody>

        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="text-center border-3 m-auto">
             <td class="px-3">
                <div class="d-flex align-items-center">
                        <span class="text-muted fw-bold text-muted d-block fs-7"><?php echo e($n->notifiable->name); ?></span>
                    </div>
                </div>
            </td>
             <td class="px-3">
                <div class="d-flex align-items-center">
                        <span class="text-muted fw-bold text-muted d-block fs-7"><?php echo e($n['data']['details']['title']); ?></span>
                    </div>
                </div>
            </td>

             <td class="px-3">
                        <span class="badge badge-light-primary fs-7 fw-bold"><?php echo e($n['data']['details']['body']); ?></span>
            </td>
           
             <td class="px-3">
                        <span class="badge badge-light-primary fs-7 fw-bold"><?php echo e($n['data']['details']['type']); ?></span>
            </td>
             <td class="px-3">
                        <span class="badge badge-light-primary fs-7 fw-bold"><?php echo e(date( 'd-m-Y h:i A',  strtotime($n->created_at))); ?></span>
            </td>
            
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
    <!--end::Table body-->
</table>
<!--end::Table-->
        <?php echo $notifications->render(); ?>


    </div>
    <!--begin::Body-->
</div>
<!--end::Tables Widget 11-->
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Billy\new app\new\resources\views/admin/notification/index.blade.php ENDPATH**/ ?>