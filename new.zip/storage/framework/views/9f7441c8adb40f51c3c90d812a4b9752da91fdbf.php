


<?php $__env->startSection('toolbar'); ?>
<div class="toolbar" id="kt_toolbar">
    <!--begin::Container-->
    <div id="kt_toolbar_container" class="container-fluid d-flex flex-stack">
        <!--begin::Page title-->
        <div class="d-flex align-items-center me-3">
            <!--begin::Title-->
            <h1 class="d-flex align-items-center text-dark fw-bolder my-1 fs-3"><?php echo app('translator')->get('Point of Sale'); ?>
            <!--begin::Separator-->
            <span class="h-20px border-gray-200 border-start ms-3 mx-2"></span>
            <!--end::Separator-->
            <!--begin::Description-->
            <small class="text-muted fs-7 fw-bold my-1 ms-1"></small>
            <!--end::Description--></h1>
            <!--end::Title-->
        </div>
        <!--end::Page title-->

    </div>
    <!--end::Container-->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card rounded mb-5 mb-xl-8 shadow-lg">
    <!--begin::Header-->
    <div class="card-header rounded border-0 pt-5">
        <h3 class="card-title align-items-start flex-column">
            <span class="card-label fw-bolder fs-3 mb-1"><?php echo app('translator')->get('Point of Sale'); ?></span>
        </h3>
    
    </div>
    <!--end::Header-->
    <!--begin::Body-->
    <div class="card-body py-3">
        <!--begin::Table container-->
        <div class="table-responsive rounded">
            <!--begin::Table-->
            <table class="table table-hover align-middle gs-0 gy-4">
                <!--begin::Table head-->
                <thead>
                    <tr class="text-center border-3 fw-bolder text-muted bg-light">
                        <th class="min-w-125px"><?php echo app('translator')->get('Title'); ?></th>
                        <th class="min-w-125px"><?php echo app('translator')->get('Description'); ?></th>
                        <th class="min-w-125px"><?php echo app('translator')->get('Action'); ?></th>
                    </tr>
                </thead>
                <!--end::Table head-->
                <!--begin::Table body-->
                <tbody>

                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-center border-3 m-auto">
                         <td class="px-3">
                            <div class="d-flex align-items-center">
                                    <span class="text-muted fw-bold text-muted d-block fs-7"><?php echo e($c->title); ?></span>
                                </div>
                            </div>
                        </td>

                         <td class="px-3">
                                    <span class="badge badge-light-primary fs-7 fw-bold"><?php echo e($c->des); ?></span>
                        </td>
                       
                       
                        








                        <td class="text-start">
                            <form id="files<?php echo e($key); ?>" action="<?php echo e(route('user.files')); ?>" method="get">
                       
                                <input type="hidden" name="user_id" value="<?php echo e($req['user_id']); ?>">
                                <input type="hidden" name="pos_id" value="<?php echo e($c->id); ?>">
                                <input type="hidden" name="date" value="<?php echo e($req['date']); ?>">
                                <input type="hidden" name="category_id" value="<?php echo e($req['category_id']); ?>">
                            </form>
                            <a href="#" onclick="event.preventDefault(); document.getElementById('files<?php echo e($key); ?>').submit();" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                                <i class="fa fa-eye"></i>
                            </a>
                            
                            


                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
                <!--end::Table body-->
            </table>
            <!--end::Table-->
        </div>
        <!--end::Table container-->
    </div>
    <!--begin::Body-->
</div>
<!--end::Tables Widget 11-->
<?php echo $data->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Billy\new app\mobapp\resources\views/admin/pos/index.blade.php ENDPATH**/ ?>