


<?php $__env->startSection('toolbar'); ?>
<div class="toolbar" id="kt_toolbar">
    <!--begin::Container-->
    <div id="kt_toolbar_container" class="container-fluid d-flex flex-stack">
        <!--begin::Page title-->
        <div class="d-flex align-items-center me-3">
            <!--begin::Title-->
            <h1 class="d-flex align-items-center text-dark fw-bolder my-1 fs-3"><?php echo app('translator')->get('Notification'); ?>
            <!--begin::Separator-->
            <span class="h-20px border-gray-200 border-start ms-3 mx-2"></span>
            <!--end::Separator-->
            <!--begin::Description-->
            <small class="text-muted fs-7 fw-bold my-1 ms-1"><?php echo app('translator')->get('create'); ?></small>
            <!--end::Description--></h1>
            <!--end::Title-->
        </div>
        <!--end::Page title-->

    </div>
    <!--end::Container-->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <div class="container-fluid page__container">

            <div class="card card-form__body card-body">
                <form method="post" action="<?php echo e(route('Notification.send')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="mb-10">
                        <label for="exampleFormControlInput1" class="required form-label"><?php echo app('translator')->get('Title'); ?> </label>
                        <input  type='text' name="title" class="form-control form-control-solid" value="<?php echo e(old('title')); ?>" />
                    </div>

                    <div class="mb-10">
                        <label for="exampleFormControlInput1" class="required form-label"><?php echo app('translator')->get('Description'); ?>  </label>
                        <textarea  name="body" class="form-control form-control-solid" ><?php echo e(old('body')); ?></textarea>
                    </div>


                    <div class="form-group mb-10">
                        <label for="exampleFormControlInput1" class="required form-label"><?php echo app('translator')->get('Type'); ?></label>

                            <select class="form-control"  name='type'>
                                        <option value='Upload Reminder'> Upload Reminder</option>
                                        <option value='Report Availability'> Report Availability</option>
                                        <option value='Subscription Expiry Reminder'> Subscription Expiry Reminder</option>
                                        <option value='Subscription Expiry Notification'> Subscription Expiry Notification</option>
                            </select>
                        </div>

                    <div class="form-group mb-10">
                        <label for="exampleFormControlInput1" class="required form-label"><?php echo app('translator')->get('Users'); ?></label>

                            <select class="form-control"  name='users[]' multiple>

                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value='<?php echo e($u->id); ?>'> <?php echo e($u->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        


                            </select>
                        </div>




                    <div class="text-right mb-5">
                        <input type="submit" name="add" class="btn btn-success" value="<?php echo app('translator')->get('Add'); ?>">
                    </div>
                </form>
            </div>
        </div>
        <!-- // END drawer-layout__content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Billy\new app\mobapp\resources\views/admin/notification/create.blade.php ENDPATH**/ ?>