<?php echo e($slot); ?>

<?php /**PATH D:\Billy\new app\mobapp\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>